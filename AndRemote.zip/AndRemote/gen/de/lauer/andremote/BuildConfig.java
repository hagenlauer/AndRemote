/** Automatically generated file. DO NOT MODIFY */
package de.lauer.andremote;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}